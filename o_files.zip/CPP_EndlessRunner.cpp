// Copyright Epic Games, Inc. All Rights Reserved.

#include "CPP_EndlessRunner.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, CPP_EndlessRunner, "CPP_EndlessRunner" );
